curl -Is http://202.83.16.87/pis.php?screen=PIS1 | head -n1
